// Product Display
let mainProduct = document.querySelector("#mainProduct")
let smallImg = document.querySelectorAll(".small-img")

smallImg[0].onclick = function() {
    mainProduct.src = smallImg[0].src;
}
smallImg[1].onclick = function() {
    mainProduct.src = smallImg[1].src;
}
smallImg[2].onclick = function() {
    mainProduct.src = smallImg[2].src;
}
smallImg[3].onclick = function() {
    mainProduct.src = smallImg[3].src;
}
// Cart

// Login,Register



function register() {
    registerform.style.transform = "translateX(0px)";
    loginform.style.transform = "translateX(0px)";
    underline.style.transform = "translateX(60px)";
}
function login() {
    registerform.style.transform = 'translateX(330px)';
    loginform.style.transform = 'translateX(330px)';
    underline.style.transform = "translateX(-60px)";
}

// Validation
function Validation() { 
   
   
    let number = document.getElementById("number").value;
    

if (number[0] !== '0') {
        alert('Số điện thoại phải bắt đầu với số \'0\'');
        return false;
}
else if(number.length < 9 || number.length > 11) {
    alert('Số điện thoại phải có hơn 9 số và dưới 11 số');
    return false;
} 

        let password = document.getElementById("password").value;
        let password1 = document.getElementById("password1").value;
        if(password != password1) {
                    alert('Mật khẩu không đồng nhất')
                    return false;
                }
}
// Barrier..............................................................................................................................................................................................................................................................

// function Forgot() {
//     let password = document.getElementById("password").value;
//     let password1 = document.getElementById("password1").value;
//     if(password != password1) {
//         alert('Mật khẩu không đồng nhất')
//         return false;
//     }
// }









